This code project is intended to collect all scripts developed to adapt Wave_clus algorithms by R. Quian Quiroga
to the analysis of MCS 60-electrode MEA recordings of cortical cultures.
In particular, the code is being developed to analyze the experiments of MBL electrical stimulation.